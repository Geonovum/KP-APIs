# Architectuur

Dit hoofdstuk geeft lezers die de API strategie toe willen passen in hun eigen organisatie een aantal best practices voor Applicatie architectuur. Deze best practices zijn gebaseerd op praktijkvoorbeelden van deelnemers aan de werkgroep Architectuur.

## <!-- 1. --> Algemeen

...

## <!-- 2. --> Thema's

In deze paragraaf wordt een verdieping gemaakt op specifieke onderwerpen (lijst onderwerpen wordt nog aangevuld/aangepast).

### Beveiliging

...

### Autorisatie

...

### Semantiek

...

### Metadata

...

### Interoperabiliteit

...

## <!-- 3. --> Patronen

...

## <!-- 4. --> Componenten

...

## <!-- 5. --> Begrippen

...

## <!-- 6. --> Standaarden

...

## <!-- 7. --> Use cases

...
